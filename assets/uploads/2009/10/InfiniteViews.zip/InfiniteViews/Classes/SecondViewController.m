//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
//
//  SecondViewController.m
//  InfiniteViews
//
//  Created by Mauricio Giraldo on 10/8/09.
//  Copyright 2009 Mauricio Giraldo. All rights reserved.
//

#import "SecondViewController.h"
#import "InfiniteViewsAppDelegate.h"

@implementation SecondViewController

@synthesize myImage;
@synthesize myControl;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}

- (void)loadAnotherView:(id)control {
	InfiniteViewsAppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
	if (myControl.selectedSegmentIndex == 0) {
		[appDelegate displayView:1];
	} else if (myControl.selectedSegmentIndex == 2) {
		[appDelegate displayView:3];
	} else if (myControl.selectedSegmentIndex == 3) {
		[appDelegate displayView:4];
	}
}	

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	// load some image
	NSString *path = [NSString stringWithFormat:@"%@/%@", [[NSBundle mainBundle] resourcePath], @"photo2.jpg"];
	UIImage *image = [UIImage imageWithContentsOfFile:path];
	self.myImage.image = image;
	// segmented control action
	[myControl addTarget:self 
				  action:@selector(loadAnotherView:) 
		forControlEvents:UIControlEventValueChanged];
    [super viewDidLoad];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	self.myImage = nil;
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

-(void)setView:(UIView*)aView {
	if (!aView){
		//set outlets to nil here
		self.myImage = nil;
		self.myControl = nil;
	}
	[super setView:aView];
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	self.myImage.image = nil;
	[self.myImage release];
	self.myImage = nil;
	self.myControl = nil;
}

- (void)dealloc {
	NSLog(@"dealloc second");
	myImage.image = nil;
	[myImage release];
	myImage = nil;
	[myControl release];
	myControl = nil;
    [super dealloc];
}


@end
