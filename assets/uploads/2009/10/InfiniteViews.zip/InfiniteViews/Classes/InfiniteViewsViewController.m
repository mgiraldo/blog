//
// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
//
//  InfiniteViewsViewController.m
//  InfiniteViews
//
//  Created by Mauricio Giraldo on 10/8/09.
//  Copyright Mauricio Giraldo 2009. All rights reserved.
//

#import "InfiniteViewsViewController.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import "FourthViewController.h"

@implementation InfiniteViewsViewController

@synthesize currentView;

- (void) displayView:(int)intNewView {
	NSLog(@"%i", intNewView);
	[self.currentView.view removeFromSuperview];
	[self.currentView release];
	switch (intNewView) {
		case 1:
			self.currentView = [[FirstViewController alloc] initWithNibName:@"FirstView" bundle:nil];
			break;
		case 2:
			self.currentView = [[SecondViewController alloc] initWithNibName:@"SecondView" bundle:nil];
			break;
		case 3:
			self.currentView = [[ThirdViewController alloc] initWithNibName:@"ThirdView" bundle:nil];
			break;
		case 4:
			self.currentView = [[FourthViewController alloc] initWithNibName:@"FourthView" bundle:nil];
			break;
	}
	
	[self.view addSubview:self.currentView.view];
}

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	self.currentView = [[FirstViewController alloc]
				   initWithNibName:@"FirstView" bundle:nil];
	[self.view addSubview:self.currentView.view];
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[currentView release];
    [super dealloc];
}

@end
